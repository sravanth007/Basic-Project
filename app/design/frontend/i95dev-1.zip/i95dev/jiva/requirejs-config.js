var config = {
    map: {
        "*": {
            stickySidebar: "js/sticky-sidebar",
        }
    }
};
